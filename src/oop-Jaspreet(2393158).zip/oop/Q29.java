
package oop;//import java.util.Scanner;

public class Q29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner kk= new Scanner(System.in);
//		System.out.print(" enter number ");
//		int nn=kk.nextInt();
		
		int nn=1;

		while(nn<=10) {
			System.out.println("number "+ nn);
			nn++;
		}
		System.out.println();
		System.out.println("done ");
	}

}
